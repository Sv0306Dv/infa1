pm2 stop remote-game-start
./node_modules/mocha/bin/mocha unit-tests.js
return $?